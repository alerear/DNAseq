/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab6inheritance;
import java.util.ArrayList;

/**
 *
 * @author alere
 */
class Professor extends Person{
    
    private String department;
    private double salary;
    private ArrayList advisees = new ArrayList<Student>();

    public Professor(String firstName, String lastName, int id, String department, double salary) {
        super(firstName, lastName, id);
        this.department = department;
        this.salary = salary;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public ArrayList<Student> getAdvisees() {
        return advisees;
    }

    public void setAdvisees(ArrayList advisees) {
        this.advisees = advisees;
    }
    
    public void addAdvisee(Student student){
        advisees.add(student);
    }
    
    public boolean removeAdvisee(int id){
        Student temp = null;
        for(Student s: advisees){
            if (s.getId() == id)){
                temp = s;   
            }
        } 
         return advisees.remove(temp);
        
    }

    @Override
    public String toString() {
        return "Professor{" + "department=" + department + ", salary=" + salary + ", advisees=" + advisees + '}';
    }
    
    
}
